# Sawit-Ku — Panduan Final

## Wajib sebelum rilis
`index.html` tidak lagi memakai Firebase demo. Aplikasi belum dapat login sampai pemilik memasukkan konfigurasi Web App Firebase yang benar. Gunakan **proyek Firebase lama yang menyimpan data pengguna** agar history tetap ada.

## Perubahan
- Konfigurasi placeholder ditolak dengan pesan setup, bukan akun demo.
- Pesan login, pendaftaran, dan reset password lebih ramah.
- Validasi email; kata sandi baru minimal 8 karakter, huruf besar, huruf kecil, angka, dan simbol.
- Nilai total pohon akun baru 0, bukan nilai contoh 108.
- Path data tetap: `artifacts/{appId}/users/{uid}/laporan_panen`, `laporan_pupuk`, dan `profile/info`.
- Logout tidak menghapus data cloud; antrean offline dipisahkan per UID.

## Konfigurasi Firebase
1. Firebase Console → buka **proyek yang sama dengan versi lama**.
2. Project settings → General → Your apps → Web app → salin konfigurasi.
3. Dalam `index.html`, cari `const firebaseConfig` dan ganti nilai `GANTI_DENGAN_...` dengan nilai dari console.
4. Authentication → Sign-in method → aktifkan Email/Password.
5. Buat/aktifkan Cloud Firestore.
6. Terapkan dan uji `firestore.rules`; jangan gunakan rules publik. Periksa aturan lama sebelum menggantinya.
7. Authentication → Settings → Authorized domains → tambahkan domain hosting.
8. Deploy melalui HTTPS/GitHub Pages, bukan membuka file lewat `file://`.

Contoh bentuk konfigurasi (gunakan nilai asli Anda):
```js
const firebaseConfig = {
  apiKey: "nilai-dari-console",
  authDomain: "project-anda.firebaseapp.com",
  projectId: "project-anda",
  storageBucket: "nilai-dari-console",
  messagingSenderId: "nilai-dari-console",
  appId: "nilai-dari-console"
};
```
Firebase Web config adalah konfigurasi klien, bukan rahasia admin. Jangan pernah menaruh service-account JSON, private key, atau kredensial admin di HTML.

## Pesan email/password dan keamanan
Firebase dengan perlindungan enumerasi email dapat menyamarkan apakah email atau password yang salah. Demi keamanan, login menampilkan “Email atau kata sandi tidak cocok” dan menawarkan reset password. Alur reset tidak membocorkan apakah suatu email terdaftar.

## Checklist tes
- [ ] Konfigurasi tidak lagi berisi `GANTI_DENGAN_...`, `demo-api-key`, atau `demo-app`.
- [ ] Akun baru dapat daftar, login, simpan catatan, logout, dan login kembali.
- [ ] Akun lama bisa masuk dan history lamanya tetap terlihat.
- [ ] Password salah memunculkan pesan ramah; reset password diuji melalui email.
- [ ] Dua akun berbeda tidak bisa membaca data satu sama lain.
- [ ] Sinkronisasi offline/online, ekspor, dan cetak diuji.
- [ ] Backup Firestore dibuat sebelum deploy.

## Batasan
File saja tidak memberi akses untuk mengaktifkan Firebase atau menguji akun cloud Anda. Produksi benar-benar siap setelah konfigurasi, rules, authorized domain, dan deploy dilakukan. Ini web/PWA, bukan APK Android bertanda tangan; APK membutuhkan build Android terpisah.
